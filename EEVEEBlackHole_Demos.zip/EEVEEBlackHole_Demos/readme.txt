Thank you for the support! :)

This package was made with Blender 2.8.

---
Social Links:
www.youtube.com/CurtisHolt
www.twitter.com/curtisjamesholt
www.instagram.com/curtisjamesholt/
www.artstation.com/curtisjamesholt
---
Discord Server:
https://discord.gg/aMDpFtc
---